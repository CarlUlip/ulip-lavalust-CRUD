<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class Student_model extends Model
{
    public function read()
    {
        return $this->db->table('ulip_student')->get_all();
    }

    public function get_paginated($limit, $offset)
    {
        return $this->db->table('ulip_student')->limit($limit, $offset)->get_all();
    }

    public function get_total_count()
    {
        $results = $this->db->table('ulip_student')->get_all(); // Fetch all records
        return count($results); // Count the records
    }

    public function create($cjru_id, $cjru_name, $cjru_course, $cjru_year_section, $cjru_birthday, $cjru_address, $cjru_email, $cjru_gender)
    {
        $data = array(
            'cjru_id' => $cjru_id,
            'cjru_name' => $cjru_name,
            'cjru_course' => $cjru_course,
            'cjru_year_section' => $cjru_year_section,
            'cjru_birthday' => $cjru_birthday,
            'cjru_address' => $cjru_address,
            'cjru_email' => $cjru_email,
            'cjru_gender' => $cjru_gender
        );
        return $this->db->table('ulip_student')->insert($data);
    }

    public function get_one($cjru_id)
    {
        return $this->db->table('ulip_student')->where('cjru_id', $cjru_id)->get();
    }

    public function update($cjru_id, $cjru_name, $cjru_course, $cjru_year_section, $cjru_birthday, $cjru_address, $cjru_email, $cjru_gender)
    {
        $data = array(
            'cjru_id' => $cjru_id,
            'cjru_name' => $cjru_name,
            'cjru_course' => $cjru_course,
            'cjru_year_section' => $cjru_year_section,
            'cjru_birthday' => $cjru_birthday,
            'cjru_address' => $cjru_address,
            'cjru_email' => $cjru_email,
            'cjru_gender' => $cjru_gender
        );
        return $this->db->table('ulip_student')->where('cjru_id', $cjru_id)->update($data);
    }

    public function delete($cjru_id)
    {
        return $this->db->table('ulip_student')->where('cjru_id', $cjru_id)->delete();
    }


    public function search_students($query)
    {
        $this->db->table('ulip_student');
        $this->db->like('cjru_id', $query);
        $this->db->or_like('cjru_name', $query);
        return $this->db->get_all();
    }
}
?>