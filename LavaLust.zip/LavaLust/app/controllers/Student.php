<?php
defined('PREVENT_DIRECT_ACCESS') or exit('No direct script access allowed');

class Student extends Controller
{

    private $limit = 5; // Number of students per page

    public function read($page = 1)
    {
        $offset = ($page - 1) * $this->limit;
        $data['stud'] = $this->student_model->get_paginated($this->limit, $offset);
        $data['total_count'] = $this->student_model->get_total_count();
        $data['total_pages'] = ceil($data['total_count'] / $this->limit);
        $data['current_page'] = $page;

        $this->call->view('student/display', $data);
    }

    public function __construct()
    {
        parent::__construct();
        $this->call->model('student_model');
    }

    public function create()
    {
        if ($this->form_validation->submitted()) {
            $cjru_id = $this->io->post('cjru_id');
            $cjru_name = $this->io->post('cjru_name');
            $cjru_course = $this->io->post('cjru_course');
            $cjru_year_section = $this->io->post('cjru_year_section');
            $cjru_birthday = $this->io->post('cjru_birthday');
            $cjru_address = $this->io->post('cjru_address');
            $cjru_email = $this->io->post('cjru_email');
            $cjru_gender = $this->io->post('cjru_gender');

            $this->student_model->create($cjru_id, $cjru_name, $cjru_course, $cjru_year_section, $cjru_birthday, $cjru_address, $cjru_email, $cjru_gender);
            header("Location: " . site_url('student/display'));
            exit;
        }
        $this->call->view('student/create');
    }

    public function update($cjru_id)
    {
        if ($this->form_validation->submitted()) {
            $cjru_id = $this->io->post('cjru_id');
            $cjru_name = $this->io->post('cjru_name');
            $cjru_course = $this->io->post('cjru_course');
            $cjru_year_section = $this->io->post('cjru_year_section');
            $cjru_birthday = $this->io->post('cjru_birthday');
            $cjru_address = $this->io->post('cjru_address');
            $cjru_email = $this->io->post('cjru_email');
            $cjru_gender = $this->io->post('cjru_gender');

            $this->student_model->update($cjru_id, $cjru_name, $cjru_course, $cjru_year_section, $cjru_birthday, $cjru_address, $cjru_email, $cjru_gender);
            header("Location: " . site_url('student/display'));
            exit;
        }
        $data['ulip_student'] = $this->student_model->get_one($cjru_id);
        $this->call->view('student/update', $data);
    }

    public function delete($cjru_id)
    {
        if ($cjru_id) {
            $this->student_model->delete($cjru_id);
        }
        header("Location: " . site_url('student/display'));
        exit;
    }


    public function search()
    {
        $query = $this->io->get('query');
        $data['is_search'] = true;

        if ($query) {
            $data['stud'] = $this->student_model->search_students($query);
        } else {
            $data['stud'] = $this->student_model->read();
        }

        $this->call->view('student/display', $data);
    }
}
?>